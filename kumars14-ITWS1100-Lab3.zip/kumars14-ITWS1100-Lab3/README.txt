Comments and Observations About Lab 3
* Had trouble pairing my Github with my Azure Instance
* Learned that I have to pull from Github each time I make a change to each file 
* Was confused on where to start my webpage but Professor Plotka helped 
* Ran into trouble with my project file CSS and then realized I had to create another CSS file for it
* Tried incorporating an icon of a laptop onto my homepage from fontawesome (learned through w3schools) but wasn�t working. 
* I love the color purple that�s why I put it for my own webpage
URL for homepage:
http://kumars14rpi.eastus.cloudapp.azure.com/iit/
URL for main page for labs
http://kumars14rpi.eastus.cloudapp.azure.com/iit/lab3/projects.html

Outlines from IA class:
Iit folder --> homepage--> lab page-->lab 1
                                                            -->lab2--> resume
                                                            -->lab3

